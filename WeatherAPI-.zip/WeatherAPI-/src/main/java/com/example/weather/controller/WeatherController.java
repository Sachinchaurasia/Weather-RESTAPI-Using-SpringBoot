package com.example.weather.controller;



import com.example.weather.entity.Weather;
import com.example.weather.service.WeatherService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/weather")
public class WeatherController {

    private final WeatherService service;

    public WeatherController(WeatherService service) {
        this.service = service;
    }

    // POST /weather
    @PostMapping
    public ResponseEntity<Weather> create(@RequestBody Weather weather) {
        Weather saved = service.create(weather);
        return ResponseEntity
                .created(URI.create("/weather/" + saved.getId()))
                .body(saved);
    }

    // GET /weather
    @GetMapping
    public ResponseEntity<List<Weather>> getAll() {
        return ResponseEntity.ok(service.findAll());
    }

    // GET /weather/{id}
    @GetMapping("/{id}")
    public ResponseEntity<Weather> getById(@PathVariable Integer id) {
        return ResponseEntity.ok(service.findById(id));
    }

    // DELETE /weather/{id}
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Integer id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}

