package com.example.weather.service.impl;



import com.example.weather.entity.Weather;
import com.example.weather.exception.ResourceNotFoundException;
import com.example.weather.repository.WeatherRepository;
import com.example.weather.service.WeatherService;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WeatherServiceImpl implements WeatherService {

    private final WeatherRepository repository;

    public WeatherServiceImpl(WeatherRepository repository) {
        this.repository = repository;
    }

    @Override
    public Weather create(Weather weather) {
        return repository.save(weather);
    }

    @Override
    public List<Weather> findAll() {
        return repository.findAll();
    }

    @Override
    public Weather findById(Integer id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Weather not found with id " + id));
    }

    @Override
    public void delete(Integer id) {
        Weather w = findById(id);
        repository.delete(w);
    }
}

