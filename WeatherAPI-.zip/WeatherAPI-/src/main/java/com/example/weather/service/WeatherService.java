package com.example.weather.service;


import com.example.weather.entity.Weather;

import java.util.List;

public interface WeatherService {

    Weather create(Weather weather);

    List<Weather> findAll();

    Weather findById(Integer id);

    void delete(Integer id);
}

